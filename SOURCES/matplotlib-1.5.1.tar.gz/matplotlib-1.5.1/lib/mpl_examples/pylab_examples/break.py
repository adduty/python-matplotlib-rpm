import matplotlib.pyplot as plt

plt.gcf().text(0.5, 0.95, 'Distance Histograms by Category is \
    a really long title')

plt.show()
